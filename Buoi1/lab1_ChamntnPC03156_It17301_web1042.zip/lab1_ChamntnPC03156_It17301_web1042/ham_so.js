function kiemTra(x) {
    if(x%2==0){
        alert(x+ " Là số chẳn");
    }else{
        alert(x+ " Là số lẻ");
    }
   }
   kiemTra(4);
   kiemTra(7);